package cluster;

public class utilVector {
	
	 public static double ComputeCosineSimilarity(double[] vector1, double[] vector2)
     {
         if (vector1.length != vector2.length)
				try {
					throw new Exception("DIFFER LENGTH");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}


         double denom = (VectorLength(vector1) * VectorLength(vector2));
         if (denom == 0)
             return 0;
         else
             return (InnerProduct(vector1, vector2) / denom);

     }
	 public static double InnerProduct(double[] vector1, double[] vector2)
     {

         if (vector1.length != vector2.length)
				try {
					throw new Exception("DIFFER LENGTH ARE NOT ALLOWED");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}


         double result = 0D;
         for (int i = 0; i < vector1.length; i++)
             result += vector1[i] * vector2[i];

         return result;
     }

	 public static double VectorLength(double[] vector)
     {
         double sum = 0.0;
         for (int i = 0; i < vector.length; i++)
             sum = sum + (vector[i] * vector[i]);

         return (double)Math.sqrt(sum);
     }
	 public static double getOsDistance(double[] vector1, double[] vector2){
		 
		 if (vector1.length != vector2.length)
				try {
					throw new Exception("DIFFER LENGTH ARE NOT ALLOWED");
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		 double sum = 0.0;
		 for(int i = 0; i < vector1.length; i++){
			 sum = sum + (vector1[i] - vector2[i])*(vector1[i] - vector2[i]);
		 }
		 
		 return (double)Math.sqrt(sum);
			
	 }


}
